# Quran extraction from QuranMajeed APK

This package was extracted from `QuranMajeedv7.8.5(Premium).apk`.

- `Quran_full_Arabic_token_export.txt`: readable UTF-8 Arabic token stream from the complete embedded script resource.
- `Quran_full_Script_i_original.bin`: untouched source resource.
- `original_resources/`: script, Indopak, English Pickthall translation, search indexes, fonts, and native Quran data libraries.
- `extraction_metadata.json`: source and integrity details.

The APK does not store the 114 surahs as ordinary separate text files; it uses proprietary binary/indexed data. The original resources are included to preserve the app’s exact data and rendering information.
